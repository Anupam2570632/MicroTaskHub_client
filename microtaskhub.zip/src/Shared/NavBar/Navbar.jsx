import { useContext, useState } from "react";
import { GiCrossMark, GiCrossShield, GiHamburgerMenu } from "react-icons/gi";
import { RiCoinsLine } from "react-icons/ri";
import { Link } from "react-router-dom";
import { AuthContext } from "../../Provider/AuthProvider/AuthContext";
import toast from "react-hot-toast";
import useUsers from "../../hooks/useUsers";
import { RxCross2 } from "react-icons/rx";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleHamburgerClick = () => {
    setIsOpen((prev) => !prev);
  };
  const { user, logOut } = useContext(AuthContext);

  const handleLogOut = () => {
    logOut()
      .then(() => {
        toast.success("Sign out successfully");
      })
      .catch();
  };
  const { serverUser, error } = useUsers(user?.email);

  // if (loading || loadUser) return <LoadingPage />;
  if (error) return <p>Error loading user.</p>;

  const links = (
    <>
      {user ? (
        <>
          <Link
            to="/dashboard/profile"
            className="py-3 px-4 font-bold hover:bg-[#2b373a] duration-200 ease-in cursor-pointer rounded-sm hover:text-[#acb3b6]"
          >
            Dashboard
          </Link>
          <li className="flex items-center justify-center gap-2 py-2 px-3">
            <RiCoinsLine className="text-2xl" />
            <div>{serverUser?.coins}</div>
          </li>
          <li className="h-12 w-12 rounded-full border-3 border-transparent hover:border-3 hover:border-white duration-150 ease-in cursor-pointer">
            <img
              className="h-full w-full rounded-full object-cover"
              src={user?.photoURL}
              alt="user.name"
            />
          </li>
          <li
            onClick={handleLogOut}
            className="py-3 px-4 font-bold hover:bg-[#2b373a] duration-200 ease-in cursor-pointer rounded-sm hover:text-[#acb3b6]"
          >
            Log Out
          </li>
        </>
      ) : (
        <>
          <Link
            to="/login"
            className="py-3 px-4 font-bold hover:bg-[#2b373a] duration-200 ease-in cursor-pointer rounded-sm hover:text-[#acb3b6]"
          >
            Login
          </Link>
          <Link
            to="/register"
            className="py-3 px-4 font-bold hover:bg-[#2b373a] duration-200 ease-in cursor-pointer rounded-sm hover:text-[#acb3b6]"
          >
            Register
          </Link>
          <a
            href="https://youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            className="py-3 px-4 font-bold text-nowrap hover:bg-[#2b373a] duration-200 ease-in cursor-pointer rounded-sm hover:text-[#acb3b6]"
          >
            Watch Demo
          </a>
        </>
      )}
    </>
  );

  return (
    <div className="fixed top-0 left-0 w-full z-50 backdrop-blur-md bg-[#182326] shadow-md text-[#e9eaea]">
      <div className="max-w-[1100px] flex items-center justify-between mx-auto py-2 px-6 relative">
        <h1 className="text-xl font-bold ">MicroTaskHub</h1>

        <div className="md:hidden relative">
          {isOpen ? (
            <RxCross2
              onClick={handleHamburgerClick}
              className="text-2xl  cursor-pointer"
            />
          ) : (
            <GiHamburgerMenu
              onClick={handleHamburgerClick}
              className="text-2xl  cursor-pointer"
            />
          )}

          <ul
            className={`absolute right-0 p-2 mt-2 bg-[#2b373a]  items-center rounded-md shadow-md flex flex-col gap-2 overflow-hidden transition-all duration-300 ease-in-out ${
              isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
            }`}
          >
            {links}
          </ul>
        </div>

        <ul className="gap-6  hidden md:flex">{links}</ul>
      </div>
    </div>
  );
};

export default Navbar;
