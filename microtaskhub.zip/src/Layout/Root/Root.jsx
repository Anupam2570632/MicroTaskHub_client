import { Outlet } from "react-router-dom";
import Navbar from "../../Shared/NavBar/Navbar";
import Footer from "../../Shared/Footer/Footer";
import FeaturesSection from "../../Components/home/FeaturedSection";
import HeroSection from "../../Components/home/HeroSection";
import HowItWorksSection from "../../Components/home/HowToStart";
import Testimonials from "../../Components/home/Testimonial";

const Root = () => {
  return (
    <div>
      <Navbar />
      <div className="mt-11 md:mt-[58px] ">
        <HeroSection />
      </div>

      <FeaturesSection />
      <HowItWorksSection />

      <Testimonials />

      <Outlet />
      <Footer />
    </div>
  );
};

export default Root;
